function [ y ] = fInverse( x )
%FINVERSE Summary of this function goes here
%   Detailed explanation goes here
y=atanh(x);

end

